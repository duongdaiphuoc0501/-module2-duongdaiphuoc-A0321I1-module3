package model.service;

import model.bean.Category;

import java.util.List;

public interface CategoryService {
    List<Category> findALl();
}
